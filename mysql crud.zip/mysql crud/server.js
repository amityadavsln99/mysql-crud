var express = require('express');
var bodyPaser = require('body-parser');
var cors = require('cors');

var app = express();

app.use(bodyPaser.json());
app.use(bodyPaser.urlencoded({extended:false}));

app.use(cors());

//import the fetch module
var fetch = require('./fetch/fetch');
app.use('/fetch',fetch);

var insert = require('./insert/insert');
app.use('/insert',insert);

var update = require('./update/update');
app.use('/update',update);

var remove = require('./delete/delete');
app.use('/delete',remove);

app.listen(8080);
console.log('Server Listing on port no 8080');